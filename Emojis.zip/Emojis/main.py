import os
import re
import tkinter as tk
from tkinter import PhotoImage

class AnalizadorLexico:
    def __init__(self, interfaz):
        self.interfaz = interfaz
        interfaz.title("Analizador Lexicográfico")

        self.titulo = tk.Label(interfaz, text="Introduce el texto:")
        self.titulo.pack()

        self.entrada = tk.Entry(interfaz, width=70)
        self.entrada.pack()

        self.boton_procesamiento = tk.Button(interfaz, text="Procesar cadena de texto", command=self.analizar_texto)
        self.boton_procesamiento.pack()

        self.letrero_salida = tk.Label(interfaz, text="Salida:")
        self.letrero_salida .pack()

        self.espacio1 = tk.Canvas(interfaz, width=500, height=50)
        self.espacio1.pack()

        self.letrero_emojis = tk.Label(interfaz, text="Emojis:")
        self.letrero_emojis.pack()

        self.espacio2 = tk.Canvas(interfaz, width=500, height=100)
        self.espacio2.pack()

        # Diccionario de mapeo de emojis a nombres de archivo
        self.nombre_emojis = {
            ':)': 'carita_feliz.png',
            ':(': 'carita_triste.png',
            ':D': 'carita_grande.png',
            ';)': 'carita_guiño.png',
            '**': 'carita_estrella.png',
            'xD': 'carita_risa.png',
            ':-)': 'carita_feliz_ext.png',
            ':-(': 'carita_triste_ext.png',
            '(y)': 'pulgar_arriba.png',
            '(n)': 'pulgar_abajo.png',
            '<3': 'corazon.png',
            '\\m/': 'mano_cuerno.png',
            ':-O': 'carita_asombrada_ext.png',
            ':O': 'carita_asombrada.png',
            ':-|': 'carita_serio_ext.png',
            ':|': 'carita_serio.png',
            ':3': 'perrito.png',
            '>:(': 'carita_enojada.png',
            '^^': 'carita_ojos_cerrados.png',
            ':-]': 'carita_ojos_cerrados_ext.png'
        }

        # Almacena referencias de imágenes
        self.imagenes_originales = []
        self.imagenes_escaladas = []


    def mostrar_resultados(self, num_palabras, num_emojis):
        resultados_texto = f"Palabras encontradas: {num_palabras} | Emojis encontrados: {num_emojis}"
        self.espacio1.delete("all")
        self.espacio1.create_text(250, 25, text=resultados_texto, font=("Helvetica", 12), anchor=tk.CENTER)

    def mostrar_emojis(self, emojis):
        ruta_carpeta_emojis = "C:/Users/posad/PycharmProjects/Emojis/png/"
        imagenes_emoji = []

        # Limpiar las referencias de imágenes anteriores
        self.imagenes_originales = []
        self.imagenes_escaladas = []

        for emoji in emojis:
            nombre_archivo_emoji = self.nombre_emojis.get(emoji)
            if nombre_archivo_emoji:
                ruta_emoji = os.path.join(ruta_carpeta_emojis, nombre_archivo_emoji)

                if os.path.exists(ruta_emoji):
                    try:
                        imagen_original = PhotoImage(file=ruta_emoji)
                        imagen_escalada = imagen_original.subsample(12, 12)
                        imagenes_emoji.append(imagen_escalada)

                        # Almacenar referencias de imágenes
                        self.imagenes_originales.append(imagen_original)
                        self.imagenes_escaladas.append(imagen_escalada)
                    finally:
                        pass

        # Limpiar el espacio antes de mostrar nuevos emojis
        self.espacio2.delete("all")

        # Mostrar emojis en el canvas
        for i, emoji_imagen in enumerate(imagenes_emoji):
            x_position = i * 50
            self.espacio2.create_image(x_position, 50, anchor=tk.W, image=emoji_imagen)

    def analizar_texto(self):
        texto_entrada = self.entrada.get()

        palabra_pattern = re.compile(r'\b[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ]+\b')
        emoji_pattern = re.compile(re.escape(r':)') + '|' +
                                   re.escape(r':(') + '|' +
                                   re.escape(r':D') + '|' +
                                   re.escape(r';)') + '|' +
                                   re.escape(r'**') + '|' +
                                   re.escape(r'xD') + '|' +
                                   re.escape(r':-)') + '|' +
                                   re.escape(r':-(') + '|' +
                                   re.escape(r'(y)') + '|' +
                                   re.escape(r'(n)') + '|' +
                                   re.escape(r'<3') + '|' +
                                   re.escape(r'\\m/') + '|' +
                                   re.escape(r':-O') + '|' +
                                   re.escape(r':O') + '|' +
                                   re.escape(r':-|') + '|' +
                                   re.escape(r':|') + '|' +
                                   re.escape(r':3') + '|' +
                                   re.escape(r'>:(') + '|' +
                                   re.escape(r'^^') + '|' +
                                   re.escape(r':-]'))

        buscar_palabras = re.findall(palabra_pattern, texto_entrada)
        emojis = re.findall(emoji_pattern, texto_entrada)

        self.mostrar_resultados(len(buscar_palabras), len(emojis))
        self.mostrar_emojis(emojis)

        print("Palabras en español (sin emojis):", buscar_palabras)
        print("Emojis:", emojis)

if __name__ == "__main__":
    root = tk.Tk()
    app = AnalizadorLexico(root)
    root.mainloop()
